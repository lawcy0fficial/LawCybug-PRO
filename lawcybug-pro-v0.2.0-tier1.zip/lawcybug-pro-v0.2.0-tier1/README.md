# LawCyBug.pro — Burp Suite Scanner Extension

A custom Burp Suite extension (Montoya API) providing additional active and
passive vulnerability checks, plus a JSON-based custom rule engine, for use
in **authorized** security testing and bug bounty programs.

## ⚠️ Honest scope statement (please read)

This is a genuinely useful, original Burp extension — but a few claims from
the original request need to be corrected up front, because shipping code
that pretends otherwise would be a disservice to you as a tester:

- **No scanner achieves "100% accuracy."** Every check here is built to
  minimize false positives (statistical timing confirmation, Collaborator
  out-of-band proof, context-aware payload shaping, three-way response
  diffing) but you should always manually verify HIGH/MEDIUM findings
  before reporting them. The confidence rating on each issue tells you how
  much manual verification it still needs.
- **This is not a clone of Burp Bounty Pro's code or rule format.** It's an
  original implementation with comparable capability (active/passive checks
  + a custom rule engine), built from scratch.
- **This is a detection tool, not an exploitation framework.** It confirms
  vulnerabilities exist and shows you the evidence (request/response,
  Collaborator interaction, timing data). It does not auto-exploit, dump
  data, or chain attacks. That's intentional — Burp Bounty Pro doesn't do
  that either, and it's the correct scope for a Burp extension.
- **This could not be compiled to a `.jar` inside the sandbox that wrote
  it** — that sandbox has no outbound network access, and building requires
  downloading the Montoya API artifact from Maven Central. You'll build the
  real `.jar` yourself with the one command below, on a machine with normal
  internet access. This takes about 30 seconds.

## What's included

**Active detectors** (send requests, confirm with evidence):
- SQL Injection — error-based, boolean-blind (3-way response diff), and
  time-based blind (statistically confirmed across MySQL/MSSQL/PostgreSQL/Oracle)
- Reflected XSS — two-phase context-aware (detects HTML body / attribute /
  script / comment context, then shapes a context-specific payload)
- OS Command Injection — time-based blind across POSIX shells, cmd.exe, PowerShell
- SSRF — genuine out-of-band confirmation via Burp Collaborator (DNS/HTTP callback)
- Server-Side Template Injection — arithmetic-confirmation across 10 engines
- Open Redirect — Location header, meta-refresh, JS redirect, bypass techniques
- CORS misconfiguration — origin reflection, null-origin, wildcard+credentials, prefix bypass
- JWT — alg:none forgery, empty-signature bypass

**Passive detectors** (analyze existing traffic only):
- Missing/misconfigured security headers (CSP, HSTS, X-Frame-Options, Referrer-Policy, Permissions-Policy)
- Information disclosure — stack traces, API keys (AWS/GitHub/OpenAI/Google/Slack), private keys, internal paths, debug panels
- JWT structural issues (alg:none already present, token in URL)
- CORS wildcard-on-authenticated-endpoint

**Custom rule engine**: load your own JSON rules (passive pattern-matching or
active payload+match) without writing Java. See `example-rules.json`.

**UI**: a "LawCyBug.pro" Burp suite tab with a live findings Dashboard,
per-detector Settings toggles, intensity control, and a Rules editor.

## Building the .jar

Requires JDK 17+ and Maven, both with normal internet access (to fetch the
Montoya API from Maven Central).

```bash
cd lawcybug-pro
mvn clean package
```

The output jar will be at:
```
target/lawcybug-pro-scanner-1.0.0.jar
```

## Loading into Burp Suite

1. Burp Suite → Extensions → Installed → Add
2. Extension type: **Java**
3. Select `target/lawcybug-pro-scanner-1.0.0.jar`
4. A "LawCyBug.pro" tab will appear in the main Burp UI.

## Using it

- Detectors run automatically as part of Burp's normal Scanner (right-click
  → "Do active scan" / passive scanning of proxied traffic), exactly like
  any built-in Burp check.
- Toggle individual detectors and adjust scan intensity / timing thresholds
  in the **Settings** sub-tab.
- SSRF detection requires **Burp Suite Professional** with a configured
  Collaborator server (Community Edition has no Collaborator access — that
  detector will silently no-op rather than error).
- Findings appear live in the **Dashboard** sub-tab and are also added to
  Burp's standard Issues / site map like any other scan check.

## Bundled rule packs (load automatically — no setup needed)

Four professional rule packs ship inside the jar itself
(`src/main/resources/rules/`) and load automatically every time the
extension starts — nothing to import, no manual step:

| File | Rules | Focus |
|---|---|---|
| `01-p1-advanced-rules.json` | 23 | General advanced web checks |
| `02-p1-mega-ruleset.json` | 139 | Broad mixed vulnerability coverage |
| `03-p1-web3-cloud-cms-webserver-rules.json` | 90 | Web3 / cloud / CMS / webserver-specific |
| `04-p1-mobile-iot-mq-cicd-rules.json` | 35 | Mobile, IoT, message queues, CI/CD |

287 rules total. The Rules sub-tab heading shows the live split,
e.g. `Custom JSON Rules (287 bundled + 0 manual = 287 total)`.

- **➕ Load from editor / Load from .json file** — *adds* rules on top of
  what's already loaded. They no longer wipe existing rules first, so
  pasting something in won't accidentally drop the bundled packs.
- **↻ Reload bundled rules** — re-reads the four files above from the jar.
  Useful after rebuilding with edited/added rule files.
- **Clear manual rules** — removes only what you loaded yourself via the
  editor/file buttons; bundled packs stay untouched.
- **Clear ALL rules** — removes everything, bundled included. Use
  "Reload bundled rules" afterward to bring them back.

To add a fifth pack permanently: drop the `.json` file into
`src/main/resources/rules/`, add its path to `BUNDLED_RULE_RESOURCES` in
`CustomRuleEngine.java`, then rebuild.

## Adding your own rules (ad-hoc, not bundled)

Open the **Rules** sub-tab, paste or load a JSON file like `example-rules.json`,
click **➕ Load from editor** (or **➕ Load from .json file**). See the inline
example in the Rules tab editor for the schema (passive: regex match against
response body/headers; active: send a payload, then check the response body,
response headers, or status code).

## Extending with more detectors

Each detector is a single class implementing `ActiveDetector` and/or
`PassiveDetector` (see `core/`), then registered in `LawCyBugExtension.java`.
This is intentionally modular — you (or I, if you ask) can add IDOR, GraphQL,
NoSQLi, XXE, deserialization, request-smuggling, or any other check the same
way without touching the engine.

## Project structure

```
src/main/java/pro/lawcybug/scanner/
├── LawCyBugExtension.java        entry point (BurpExtension.initialize)
├── core/                          engine, settings, issue factory, interfaces
├── detectors/
│   ├── sqli/      error-based, boolean-blind, time-based + payload library
│   ├── xss/       context-aware reflected XSS
│   ├── cmdi/      blind command injection
│   ├── ssrf/      Collaborator OOB SSRF + SSTI
│   ├── cors/      CORS misconfiguration
│   ├── redirect/  open redirect
│   ├── jwt/       JWT misconfiguration
│   ├── headers/   security header audit
│   └── info/      secret/stack-trace/path disclosure
├── rules/         JSON custom rule engine + zero-dependency JSON parser
├── ui/            Burp suite tab (Dashboard / Settings / Rules)
└── util/          timing statistics, response diffing, canary tokens
```

~3,500 lines of original Java across 28 files.
